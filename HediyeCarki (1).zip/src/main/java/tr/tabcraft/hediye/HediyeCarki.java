package tr.tabcraft.hediye;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * TabCraft Yilbasi Hediye Carki.
 *
 * Menu 6 satirlik sandik. Arka plan, texture pack icindeki "tabcraft:cark" fontundan
 * baslik karakteriyle cizilir (carkin resmi). Esyalar resmin ustundeki slotlara konur:
 *  - 8 odul slotu carkin cevresinde (tepeden baslayip saat yonunde)
 *  - 8 ibre slotu ic halkada (ibre topu burada doner)
 *  - Merkez slot (22) = CEVIR dugmesi (resimde cizili, slot bos)
 *  - Slot 45 = Odul Bilgisi kitabi
 */
public final class HediyeCarki extends JavaPlugin implements Listener, TabExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    /** Odul slotlari: N, NE, E, SE, S, SW, W, NW. */
    private static final int[] PRIZE_SLOTS = {4, 6, 24, 42, 40, 38, 20, 2};
    /** Ibre topunun gidecegi ic halka slotlari (odullerle ayni sira). */
    private static final int[] POINTER_SLOTS = {13, 14, 23, 32, 31, 30, 21, 12};
    private static final int CENTER = 22;
    private static final int INFO_SLOT = 45;
    private static final long FOREVER = Long.MAX_VALUE;

    private static final String[] TIERS = {"kotu", "orta", "iyi"};

    private record Prize(String tier, String ad, Material icon, int amount, Material give, String command) {}

    private static final class HediyeHolder implements InventoryHolder {
        Inventory inv;
        boolean closed;
        Spin spin;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final class Spin {
        Player player;
        HediyeHolder holder;
        Prize winner;
        int winnerIdx;
        int pos;
        int steps;
        int total;
        boolean done;
        BukkitTask task;
    }

    private final List<Prize> prizes = new ArrayList<>();
    private final Map<UUID, Long> lastSpin = new HashMap<>();
    private final Map<UUID, Spin> spins = new HashMap<>();
    private File dataFile;

    // ------------------------------------------------------------------ yasam dongusu

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        loadPrizes();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("yılbaşıçarkı");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        for (Spin s : new ArrayList<>(spins.values())) {
            s.holder.closed = true;
            finish(s);
        }
        saveData();
    }

    // ------------------------------------------------------------------ yukleme

    private Material mat(String name) {
        Material m = name == null ? null : Material.matchMaterial(name);
        if (m == null) {
            getLogger().warning("Bilinmeyen esya: " + name);
            return Material.BARRIER;
        }
        return m;
    }

    private void loadPrizes() {
        prizes.clear();
        ConfigurationSection sec = getConfig().getConfigurationSection("oduller");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(k);
            if (s == null) continue;
            String tier = s.getString("tier", "kotu").toLowerCase(Locale.ROOT);
            String ad = s.getString("ad", k);
            Material icon = mat(s.getString("ikon", "STONE"));
            int amount = Math.max(1, Math.min(64, s.getInt("miktar", 1)));
            String giveStr = s.getString("esya");
            Material give = giveStr != null ? mat(giveStr) : icon;
            String cmd = s.getString("komut");
            if (cmd != null && cmd.isBlank()) cmd = null;
            prizes.add(new Prize(tier, ad, icon, amount, give, cmd));
            if (prizes.size() == 8) break;
        }
        if (prizes.size() != 8) {
            getLogger().warning("Cark tam 8 odul ister, config'de " + prizes.size() + " var.");
        }
    }

    private void loadData() {
        lastSpin.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = y.getConfigurationSection("son-cevirme");
        if (sec == null) return;
        for (String k : sec.getKeys(false)) {
            try {
                lastSpin.put(UUID.fromString(k), sec.getLong(k));
            } catch (IllegalArgumentException ignored) {
                // bozuk kayit atlanir
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : lastSpin.entrySet()) {
            y.set("son-cevirme." + e.getKey(), e.getValue());
        }
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("data.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ yardimcilar

    private Component comp(String s) {
        return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack named(Material m, int amount, String name, List<String> lore, boolean glint) {
        ItemStack it = new ItemStack(m, amount);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(comp(name));
        if (lore != null && !lore.isEmpty()) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(comp(s));
            meta.lore(l);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        if (glint) meta.setEnchantmentGlintOverride(Boolean.TRUE);
        it.setItemMeta(meta);
        return it;
    }

    private String fill(String s, Player p, Prize pr, String sure) {
        String out = s.replace("%oyuncu%", p.getName());
        String ad = pr != null ? pr.ad() : "";
        out = out.replace("%ödül%", ad).replace("%odul%", ad);
        if (sure != null) out = out.replace("%sure%", sure);
        return out;
    }

    private void sendLines(Player p, String path, Prize pr) {
        for (String line : getConfig().getStringList(path)) {
            p.sendMessage(LEGACY.deserialize(fill(line, p, pr, null)));
        }
    }

    private String tierLabel(String t) {
        return switch (t) {
            case "iyi" -> "&a★ İyi Ödül";
            case "orta" -> "&e★ Orta Ödül";
            default -> "&c★ Kötü Ödül";
        };
    }

    private String tierPlural(String t) {
        return switch (t) {
            case "iyi" -> "&a★ İyi Ödüller";
            case "orta" -> "&e★ Orta Ödüller";
            default -> "&c★ Kötü Ödüller";
        };
    }

    private List<Prize> prizesOf(String tier) {
        List<Prize> l = new ArrayList<>();
        for (Prize p : prizes) {
            if (p.tier().equals(tier)) l.add(p);
        }
        return l;
    }

    private long chancePct(String tier) {
        double total = 0;
        for (String t : TIERS) {
            if (!prizesOf(t).isEmpty()) total += getConfig().getDouble("sans." + t, 0);
        }
        if (total <= 0) return 0;
        return Math.round(getConfig().getDouble("sans." + tier, 0) / total * 100.0);
    }

    private String formatTime(long ms) {
        long s = ms / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return h + " sa " + m + " dk";
        if (m > 0) return m + " dk " + sec + " sn";
        return sec + " sn";
    }

    private boolean oneTime() {
        return getConfig().getBoolean("tek-hak", true);
    }

    private long remaining(Player p) {
        if (p.hasPermission("hediye.bypass")) return 0;
        Long last = lastSpin.get(p.getUniqueId());
        if (last == null) return 0;
        if (oneTime()) return FOREVER;
        long hours = getConfig().getLong("bekleme-saat", 24);
        if (hours <= 0) return 0;
        long left = last + hours * 3600_000L - System.currentTimeMillis();
        return Math.max(left, 0);
    }

    // ------------------------------------------------------------------ menu cizimi

    private Component menuTitle() {
        if (getConfig().getBoolean("cark-resim", true)) {
            // \uE001 = sola 8 piksel kaydirma, \uE000 = carkin arka plan resmi (texture pack)
            return Component.text("\uE001\uE000", NamedTextColor.WHITE).font(Key.key("tabcraft", "cark"));
        }
        return LEGACY.deserialize(getConfig().getString("menu-baslik", "&5&l✦ &d&lHEDİYE ÇARKI &5&l✦"));
    }

    private ItemStack icon(Prize pr, boolean lit) {
        String name = lit ? "&e&l▶ " + pr.ad() : "&f&l" + pr.ad();
        return named(pr.icon(), pr.amount(), name, List.of("", tierLabel(pr.tier())), lit);
    }

    private ItemStack pointerBall() {
        return named(Material.GLOWSTONE_DUST, 1, "&e&l▶", null, true);
    }

    private void openMenu(Player p) {
        if (prizes.size() != 8) {
            p.sendMessage(LEGACY.deserialize("&cÇark şu an kullanılamıyor (ödül ayarı hatalı). Yöneticiye haber ver."));
            return;
        }
        HediyeHolder h = new HediyeHolder();
        Inventory inv = Bukkit.createInventory(h, 54, menuTitle());
        h.inv = inv;
        buildStatic(inv);
        renderCenter(inv, p);
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.8f, 1.2f);
    }

    private void buildStatic(Inventory inv) {
        for (int i = 0; i < 8; i++) {
            inv.setItem(PRIZE_SLOTS[i], icon(prizes.get(i), false));
        }

        List<String> lore = new ArrayList<>();
        lore.add("&7Bu çarktan &f8 &7farklı ödül kazanabilirsin!");
        lore.add("");
        lore.add("&6&lÖdül Dağılımı:");
        for (String t : TIERS) {
            List<Prize> list = prizesOf(t);
            if (list.isEmpty()) continue;
            lore.add("");
            lore.add(tierPlural(t) + " &7(" + list.size() + " adet) &8| &f%" + chancePct(t));
            for (Prize pr : list) {
                lore.add("&8+ &f" + pr.ad());
            }
        }
        lore.add("");
        lore.add("&dŞansını dene ve ödülünü kap!");
        inv.setItem(INFO_SLOT, named(Material.BOOK, 1, "&d&lÖdül Bilgisi", lore, false));
    }

    /** Hak varsa merkez bos kalir (resimdeki CEVIR dugmesi gorunur), yoksa bariyer koyulur. */
    private void renderCenter(Inventory inv, Player p) {
        long rem = remaining(p);
        if (rem == FOREVER) {
            inv.setItem(CENTER, named(Material.BARRIER, 1, "&c&lHAKKIN KALMADI",
                    List.of("", "&7Çarkı sadece &f1 &7kez çevirebilirsin."), false));
        } else if (rem > 0) {
            inv.setItem(CENTER, named(Material.BARRIER, 1, "&c&lBEKLE",
                    List.of("", "&7Kalan süre: &f" + formatTime(rem)), false));
        } else {
            inv.setItem(CENTER, null);
        }
    }

    private void lightPos(Inventory inv, int idx, boolean lit) {
        inv.setItem(PRIZE_SLOTS[idx], icon(prizes.get(idx), lit));
        inv.setItem(POINTER_SLOTS[idx], lit ? pointerBall() : null);
    }

    // ------------------------------------------------------------------ tiklama

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof HediyeHolder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != top) return;
        if (e.getRawSlot() != CENTER) return;
        tryStart(p, h);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof HediyeHolder) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof HediyeHolder h)) return;
        h.closed = true;
        if (h.spin != null) {
            finish(h.spin);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Spin s = spins.get(e.getPlayer().getUniqueId());
        if (s != null) {
            s.holder.closed = true;
            finish(s);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!getConfig().getBoolean("giriste-hatirlat", true)) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && remaining(p) == 0) {
                sendLines(p, "mesajlar.acilis", null);
            }
        }, 80L);
    }

    // ------------------------------------------------------------------ cevirme

    private int pickWinnerIndex() {
        double total = 0;
        for (String t : TIERS) {
            if (!prizesOf(t).isEmpty()) total += getConfig().getDouble("sans." + t, 0);
        }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        if (total <= 0) return rnd.nextInt(prizes.size());
        double r = rnd.nextDouble(total);
        String chosen = TIERS[TIERS.length - 1];
        double acc = 0;
        for (String t : TIERS) {
            if (prizesOf(t).isEmpty()) continue;
            acc += getConfig().getDouble("sans." + t, 0);
            if (r < acc) {
                chosen = t;
                break;
            }
        }
        List<Integer> idxs = new ArrayList<>();
        for (int i = 0; i < prizes.size(); i++) {
            if (prizes.get(i).tier().equals(chosen)) idxs.add(i);
        }
        if (idxs.isEmpty()) return rnd.nextInt(prizes.size());
        return idxs.get(rnd.nextInt(idxs.size()));
    }

    private void tryStart(Player p, HediyeHolder h) {
        if (h.spin != null || h.closed) return;
        long rem = remaining(p);
        if (rem > 0) {
            if (rem == FOREVER) {
                String m = getConfig().getString("mesajlar.hak-yok", "&cHediye hakkını zaten kullandın!");
                p.sendMessage(LEGACY.deserialize(fill(m, p, null, null)));
            } else {
                String m = getConfig().getString("mesajlar.bekle", "&cBekle: %sure%");
                p.sendMessage(LEGACY.deserialize(fill(m, p, null, formatTime(rem))));
            }
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        Spin s = new Spin();
        s.player = p;
        s.holder = h;
        s.winnerIdx = pickWinnerIndex();
        s.winner = prizes.get(s.winnerIdx);
        s.pos = 0;
        s.steps = 0;
        s.total = 32 + s.winnerIdx;   // 4 tam tur + odule kadar

        if (!p.hasPermission("hediye.bypass")) {
            lastSpin.put(p.getUniqueId(), System.currentTimeMillis());
            saveData();
        }
        h.spin = s;
        spins.put(p.getUniqueId(), s);

        h.inv.setItem(CENTER, named(Material.CLOCK, 1, "&e&l⟳ Çark dönüyor...",
                List.of("", "&7Bol şans!"), true));
        lightPos(h.inv, 0, true);
        p.sendMessage(LEGACY.deserialize(fill(getConfig().getString("mesajlar.basla", ""), p, null, null)));
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.2f);

        s.task = Bukkit.getScheduler().runTaskLater(this, () -> step(s), 8L);
    }

    private void step(Spin s) {
        if (s.done) return;
        Player p = s.player;
        if (!p.isOnline() || s.holder.closed) {
            finish(s);
            return;
        }
        Inventory inv = s.holder.inv;
        int prev = s.pos;
        s.pos = (s.pos + 1) % 8;
        s.steps++;
        lightPos(inv, prev, false);
        lightPos(inv, s.pos, true);

        float pitch = 0.8f + 0.9f * ((float) s.steps / (float) s.total);
        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.6f, pitch);

        if (s.steps >= s.total) {
            s.task = Bukkit.getScheduler().runTaskLater(this, () -> finish(s), 10L);
            return;
        }
        int r = s.total - s.steps;
        long delay = r > 14 ? 2L : r > 9 ? 3L : r > 6 ? 4L : r > 4 ? 6L : r > 2 ? 8L : r > 1 ? 11L : 14L;
        s.task = Bukkit.getScheduler().runTaskLater(this, () -> step(s), delay);
    }

    private void finish(Spin s) {
        if (s.done) return;
        s.done = true;
        if (s.task != null) s.task.cancel();
        spins.remove(s.player.getUniqueId());
        s.holder.spin = null;

        Player p = s.player;
        Prize pr = s.winner;
        award(p, pr);

        sendLines(p, "mesajlar.kazandin", pr);
        Title title = Title.title(
                LEGACY.deserialize("&6&l✦ TEBRİKLER ✦"),
                LEGACY.deserialize("&e" + pr.ad()),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(600)));
        p.showTitle(title);

        switch (pr.tier()) {
            case "iyi" -> {
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1f, 1f);
                p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1f, 1f);
            }
            case "orta" -> {
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
                p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1f, 1f);
            }
            default -> p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        }
        winEffects(p, pr.tier());

        if (pr.tier().equals("iyi") && getConfig().getBoolean("iyi-odul-duyurusu", true)) {
            Bukkit.broadcast(LEGACY.deserialize(
                    fill(getConfig().getString("mesajlar.duyuru-iyi", ""), p, pr, null)));
        }

        if (!s.holder.closed && isEnabled()) {
            showWinner(s);
        }
    }

    private void award(Player p, Prize pr) {
        if (pr.command() != null) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), pr.command().replace("%oyuncu%", p.getName()));
            return;
        }
        ItemStack it = new ItemStack(pr.give(), pr.amount());
        HashMap<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack rest : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }

    // ------------------------------------------------------------------ kazanma efektleri

    private void winEffects(Player p, String tier) {
        World w = p.getWorld();
        Location l = p.getLocation().add(0, 1, 0);
        Color c = switch (tier) {
            case "iyi" -> Color.fromRGB(255, 200, 0);
            case "orta" -> Color.AQUA;
            default -> Color.fromRGB(170, 170, 170);
        };
        Particle.DustOptions d = new Particle.DustOptions(c, 1.4f);
        boolean good = tier.equals("iyi");
        w.spawnParticle(Particle.END_ROD, l, good ? 50 : 25, 0.6, 0.9, 0.6, 0.08);
        w.spawnParticle(Particle.DUST, l, 40, 0.7, 0.9, 0.7, 0, d);

        if (good && isEnabled()) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!p.isOnline()) return;
                Location l2 = p.getLocation().add(0, 1, 0);
                World w2 = p.getWorld();
                w2.spawnParticle(Particle.END_ROD, l2, 40, 0.8, 1.0, 0.8, 0.12);
                w2.spawnParticle(Particle.DUST, l2, 30, 0.8, 1.0, 0.8, 0, new Particle.DustOptions(Color.RED, 1.3f));
                w2.spawnParticle(Particle.DUST, l2, 30, 0.8, 1.0, 0.8, 0, new Particle.DustOptions(Color.fromRGB(0, 170, 0), 1.3f));
            }, 8L);
        }
    }

    private void showWinner(Spin s) {
        final HediyeHolder h = s.holder;
        final Inventory inv = h.inv;
        final Prize pr = s.winner;
        final int win = s.winnerIdx;

        inv.setItem(CENTER, named(pr.icon(), pr.amount(), "&6&l✦ " + pr.ad() + " &6&l✦",
                List.of("", "&7Ödülün verildi!"), true));
        inv.setItem(PRIZE_SLOTS[win], icon(pr, true));

        // kazanma animasyonu: ibre toplari dalga gibi yanip soner, sonunda sadece kazanan kalir
        new BukkitRunnable() {
            int n = 0;

            @Override
            public void run() {
                if (h.closed) {
                    cancel();
                    return;
                }
                if (n >= 16) {
                    for (int i = 0; i < 8; i++) {
                        inv.setItem(POINTER_SLOTS[i], i == win ? pointerBall() : null);
                    }
                    cancel();
                    return;
                }
                for (int i = 0; i < 8; i++) {
                    inv.setItem(POINTER_SLOTS[i], ((i + n) % 2 == 0) ? pointerBall() : null);
                }
                n++;
            }
        }.runTaskTimer(this, 0L, 3L);
    }

    // ------------------------------------------------------------------ komut

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            if (s instanceof Player p) {
                openMenu(p);
            } else {
                s.sendMessage("Bu komut sadece oyuncular için.");
            }
            return true;
        }
        if (!s.hasPermission("hediye.admin")) {
            s.sendMessage(LEGACY.deserialize("&cBu komutu kullanma iznin yok."));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "sifirla" -> {
                if (a.length < 2) {
                    s.sendMessage(LEGACY.deserialize("&cKullanım: /yılbaşıçarkı sifirla <oyuncu>"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(LEGACY.deserialize("&cOyuncu çevrimiçi değil: " + a[1]));
                    return true;
                }
                lastSpin.remove(t.getUniqueId());
                saveData();
                s.sendMessage(LEGACY.deserialize("&a" + t.getName() + " oyuncusunun hakkı sıfırlandı."));
            }
            case "duyuru" -> {
                for (Player pl : Bukkit.getOnlinePlayers()) {
                    sendLines(pl, "mesajlar.acilis", null);
                }
            }
            case "yenile" -> {
                reloadConfig();
                loadPrizes();
                loadData();
                s.sendMessage(LEGACY.deserialize("&aYenilendi."));
            }
            default -> s.sendMessage(LEGACY.deserialize(
                    "&f/yılbaşıçarkı &7| &f/yılbaşıçarkı sifirla <oyuncu> &7| &f/yılbaşıçarkı duyuru &7| &f/yılbaşıçarkı yenile"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("hediye.admin")) return out;
        if (a.length == 1) {
            for (String x : List.of("sifirla", "duyuru", "yenile")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(x);
            }
        } else if (a.length == 2 && a[0].equalsIgnoreCase("sifirla")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }
}
